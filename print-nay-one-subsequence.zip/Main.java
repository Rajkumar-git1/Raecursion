import java.util.*;

class Main {

    static boolean f(int[] v, int index, int csum, int k, ArrayList<Integer> ds) {
        // base case
        if (index == v.length) {
            if (csum == k) {
                System.out.println(ds); 
                return true;           
            }
            return false;
        }
        ds.add(v[index]);
        if (f(v, index + 1, csum + v[index], k, ds)) return true;

        ds.remove(ds.size() - 1);
        if (f(v, index + 1, csum, k, ds)) return true;

        return false;
    }

    public static void main(String[] args) {
        int v[] = {3, 2, 1};
        int k = 3;

        f(v, 0, 0, k, new ArrayList<>());
    }
}
