import java.util.*;

class Main {

    static void f(int[] v, int index, int csum, int n, int k) {
        // base 
        if (index == n) {
            if (csum == k) {
                System.out.println(csum);
            }
            return;
        }
        csum += v[index];
        f(v, index + 1, csum, n, k);

        
        csum -= v[index];
        f(v, index + 1, csum, n, k);
    }

    public static void main(String args[]) {
        int v[] = {3, 2, 1};
        int k = 3;

        f(v, 0, 0, v.length, k);
    }
}
